import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Play } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function PhilosophySection() {
  const sectionRef = useRef<HTMLElement>(null);
  const labelRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subheadlineRef = useRef<HTMLParagraphElement>(null);
  const videoRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);
  const lineRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // Phase 1: ENTRANCE (0%-30%)
      scrollTl.fromTo(
        lineRef.current,
        { scaleX: 0, opacity: 0 },
        { scaleX: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        labelRef.current,
        { y: -20, opacity: 0 },
        { y: 0, opacity: 1, ease: 'power2.out' },
        0.02
      );

      scrollTl.fromTo(
        headlineRef.current?.querySelectorAll('.word') || [],
        { y: 60, opacity: 0 },
        { y: 0, opacity: 1, ease: 'power2.out', stagger: 0.02 },
        0.05
      );

      scrollTl.fromTo(
        subheadlineRef.current,
        { y: 30, opacity: 0 },
        { y: 0, opacity: 1, ease: 'power2.out' },
        0.12
      );

      scrollTl.fromTo(
        videoRef.current,
        { scale: 0.92, y: 80, opacity: 0 },
        { scale: 1, y: 0, opacity: 1, ease: 'power2.out' },
        0.10
      );

      scrollTl.fromTo(
        ctaRef.current,
        { y: '18vh', scale: 0.85, opacity: 0 },
        { y: 0, scale: 1, opacity: 1, ease: 'back.out(1.5)' },
        0.14
      );

      // Phase 3: EXIT (70%-100%)
      scrollTl.fromTo(
        headlineRef.current?.querySelectorAll('.word') || [],
        { y: 0, opacity: 1 },
        { y: '-18vh', opacity: 0, ease: 'power2.in', stagger: 0.01 },
        0.70
      );

      scrollTl.fromTo(
        [labelRef.current, subheadlineRef.current, lineRef.current],
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.72
      );

      scrollTl.fromTo(
        videoRef.current,
        { scale: 1, opacity: 1 },
        { scale: 1.06, opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(
        ctaRef.current,
        { y: 0, opacity: 1 },
        { y: '22vh', opacity: 0, ease: 'power2.in' },
        0.70
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned z-20 bg-[#0B0B0D]"
    >
      {/* Vignette overlay */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse at center, transparent 0%, rgba(11,11,13,0.4) 100%)'
        }}
      />

      {/* Content */}
      <div className="relative z-10 h-full flex flex-col items-center pt-[10vh]">
        {/* Hairline */}
        <div 
          ref={lineRef}
          className="hairline w-[28vw] mb-6 origin-center"
        />

        {/* Label */}
        <div ref={labelRef} className="label-small text-[#C9A87C] mb-8">
          DESIGN STUDIOS IN GURUGRAM & GOA
        </div>

        {/* Headline */}
        <h2 
          ref={headlineRef}
          className="headline-lg text-[#F5F2EC] text-center max-w-[86vw] px-4"
        >
          <span className="word inline-block">We</span>{' '}
          <span className="word inline-block">design</span>{' '}
          <span className="word inline-block">spaces</span>{' '}
          <span className="word inline-block">that</span>{' '}
          <span className="word inline-block">feel</span>{' '}
          <span className="word inline-block">as</span>{' '}
          <span className="word inline-block">good</span>{' '}
          <span className="word inline-block">as</span>{' '}
          <span className="word inline-block">they</span>{' '}
          <span className="word inline-block">look.</span>
        </h2>

        {/* Subheadline */}
        <p 
          ref={subheadlineRef}
          className="body-text text-[#B8B2AA] text-center max-w-[64vw] mt-8 px-4"
        >
          Collaboration first. Timeless materials. Calm, cohesive interiors tailored to how you actually live.
        </p>

        {/* Video Thumbnail */}
        <div 
          ref={videoRef}
          className="mt-12 relative cursor-pointer group"
          style={{ width: 'min(52vw, 720px)' }}
        >
          <div className="aspect-video border border-[rgba(245,242,236,0.25)] overflow-hidden">
            <img
              src="/living_room_feature.jpg"
              alt="Our Process"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            {/* Play button overlay */}
            <div className="absolute inset-0 flex items-center justify-center bg-[rgba(11,11,13,0.3)]">
              <div className="w-16 h-16 rounded-full border-2 border-[#F5F2EC] flex items-center justify-center transition-all duration-300 group-hover:scale-110 group-hover:border-[#C9A87C]">
                <Play className="w-6 h-6 text-[#F5F2EC] ml-1" fill="currentColor" />
              </div>
            </div>
          </div>
          <p className="label-small text-[#B8B2AA] mt-4 text-center">
            Watch our process (1 min)
          </p>
        </div>
      </div>

      {/* CTA Circle */}
      <button
        ref={ctaRef}
        className="cta-circle absolute left-1/2 bottom-[7vh] -translate-x-1/2 z-20"
      >
        <span>Explore</span>
      </button>
    </section>
  );
}
