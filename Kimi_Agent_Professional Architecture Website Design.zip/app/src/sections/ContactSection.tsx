import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Phone, Mail, MapPin, Instagram } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function ContactSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const lineRef = useRef<HTMLDivElement>(null);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
  });
  const [submitted, setSubmitted] = useState(false);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Headline animation
      gsap.fromTo(
        headlineRef.current,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: headlineRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Line animation
      gsap.fromTo(
        lineRef.current,
        { scaleX: 0 },
        {
          scaleX: 1,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: lineRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Contact card animation
      gsap.fromTo(
        cardRef.current,
        { x: '8vw', opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: cardRef.current,
            start: 'top 75%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Form fields animation
      const formFields = formRef.current?.querySelectorAll('.form-field');
      if (formFields) {
        gsap.fromTo(
          formFields,
          { y: 24, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            ease: 'power2.out',
            stagger: 0.08,
            scrollTrigger: {
              trigger: formRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, section);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    // Reset after 3 seconds
    setTimeout(() => {
      setSubmitted(false);
      setFormData({ name: '', email: '', phone: '' });
    }, 3000);
  };

  return (
    <section
      ref={sectionRef}
      className="relative bg-[#6E4F3A] min-h-screen z-[80]"
    >
      <div className="px-[7vw] py-[12vh]">
        <div className="flex flex-col lg:flex-row lg:justify-between lg:items-start gap-12">
          {/* Left Column - Headline */}
          <div ref={headlineRef} className="lg:max-w-[46vw]">
            <h2 className="headline-lg text-[#F5F2EC]">
              Ready to discuss<br />your dream home?
            </h2>
            <div ref={lineRef} className="hairline w-[10vw] mt-8 origin-left" />
            <p className="body-text text-[#B8B2AA] mt-8 max-w-[36vw]">
              Share a few details and we'll respond within two business days.
            </p>
          </div>

          {/* Right Column - Contact Card */}
          <div 
            ref={cardRef}
            className="border border-[rgba(245,242,236,0.25)] p-8 lg:w-[420px]"
          >
            <h3 className="font-display text-2xl text-[#F5F2EC] mb-6">
              Book a consultation
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <Phone className="w-5 h-5 text-[#C9A87C]" />
                <span className="body-text text-[#F5F2EC]">+91-9560450445</span>
              </div>
              
              <div className="flex items-center gap-4">
                <Mail className="w-5 h-5 text-[#C9A87C]" />
                <span className="body-text text-[#F5F2EC]">info@mishulgupta.in</span>
              </div>
              
              <div className="flex items-start gap-4">
                <MapPin className="w-5 h-5 text-[#C9A87C] mt-1" />
                <span className="body-text text-[#F5F2EC]">
                  D-31, Sector 57<br />
                  Gurugram, Haryana
                </span>
              </div>

              <a 
                href="https://instagram.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-4 mt-6 group"
              >
                <Instagram className="w-5 h-5 text-[#C9A87C] transition-transform group-hover:scale-110" />
                <span className="body-text text-[#F5F2EC] group-hover:text-[#C9A87C] transition-colors">
                  Follow on Instagram
                </span>
              </a>
            </div>
          </div>
        </div>

        {/* Form Section */}
        <form 
          ref={formRef}
          onSubmit={handleSubmit}
          className="mt-16 pt-8 border-t border-[rgba(245,242,236,0.15)]"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="form-field">
              <label className="label-small text-[#B8B2AA] mb-2 block">Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="form-input"
                placeholder="Your name"
                required
              />
            </div>
            
            <div className="form-field">
              <label className="label-small text-[#B8B2AA] mb-2 block">Email</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="form-input"
                placeholder="your@email.com"
                required
              />
            </div>
            
            <div className="form-field">
              <label className="label-small text-[#B8B2AA] mb-2 block">Phone</label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="form-input"
                placeholder="+91..."
                required
              />
            </div>
          </div>

          <div className="form-field mt-8 flex flex-col sm:flex-row items-start sm:items-center gap-6">
            <button type="submit" className="btn-primary">
              {submitted ? 'Sent!' : 'Download portfolio'}
            </button>
            <p className="body-text text-[#B8B2AA] text-sm">
              PDF portfolio + process guide sent to your email.
            </p>
          </div>
        </form>

        {/* Footer */}
        <footer className="mt-20 pt-8 border-t border-[rgba(245,242,236,0.15)]">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div>
              <h4 className="font-display text-xl text-[#F5F2EC]">Mishul Gupta</h4>
              <p className="body-text text-[#B8B2AA] text-sm mt-1">
                Architecture & Interior Design
              </p>
            </div>
            
            <nav className="flex gap-8">
              <a href="#portfolio" className="nav-link">Portfolio</a>
              <a href="#about" className="nav-link">About</a>
              <a href="#contact" className="nav-link">Contact</a>
            </nav>
            
            <p className="body-text text-[#B8B2AA] text-xs">
              © 2024 Mishul Gupta. All rights reserved.
            </p>
          </div>
        </footer>
      </div>
    </section>
  );
}
