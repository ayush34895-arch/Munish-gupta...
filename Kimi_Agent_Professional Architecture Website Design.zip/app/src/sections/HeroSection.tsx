import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface HeroSectionProps {
  onEnterClick: () => void;
}

export default function HeroSection({ onEnterClick }: HeroSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const subheadlineRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const headline = headlineRef.current;
    const subheadline = subheadlineRef.current;
    const cta = ctaRef.current;
    const bg = bgRef.current;

    if (!section || !headline || !subheadline || !cta || !bg) return;

    const ctx = gsap.context(() => {
      // Initial states
      gsap.set(bg, { opacity: 0, scale: 1.08 });
      gsap.set(headline.querySelectorAll('.word'), { y: 40, opacity: 0 });
      gsap.set(subheadline, { y: 18, opacity: 0 });
      gsap.set(cta, { scale: 0.75, opacity: 0, rotate: -12 });

      // Entrance animation timeline
      const entranceTl = gsap.timeline({ delay: 0.2 });

      entranceTl
        .to(bg, {
          opacity: 1,
          scale: 1,
          duration: 1.1,
          ease: 'power2.out',
        })
        .to(headline.querySelectorAll('.word'), {
          y: 0,
          opacity: 1,
          duration: 0.9,
          ease: 'power3.out',
          stagger: 0.06,
        }, '-=0.7')
        .to(subheadline, {
          y: 0,
          opacity: 1,
          duration: 0.7,
          ease: 'power2.out',
        }, '-=0.5')
        .to(cta, {
          scale: 1,
          opacity: 1,
          rotate: 0,
          duration: 0.8,
          ease: 'back.out(1.6)',
        }, '-=0.4');

      // Scroll-driven exit animation
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset to visible when scrolling back to top
            gsap.to(headline.querySelectorAll('.word'), { x: 0, opacity: 1, duration: 0.3 });
            gsap.to(subheadline, { x: 0, opacity: 1, duration: 0.3 });
            gsap.to(cta, { y: 0, scale: 1, opacity: 1, duration: 0.3 });
            gsap.to(bg, { scale: 1, opacity: 1, duration: 0.3 });
          },
        },
      });

      // Phase 1: ENTRANCE (0%-30%) - subtle background drift
      scrollTl.fromTo(
        bg,
        { scale: 1 },
        { scale: 1.02, ease: 'none' },
        0
      );

      // Phase 2: SETTLE (30%-70%) - hold position

      // Phase 3: EXIT (70%-100%)
      scrollTl.fromTo(
        headline.querySelectorAll('.word'),
        { x: 0, opacity: 1 },
        { x: '-40vw', opacity: 0, ease: 'power2.in', stagger: 0.02 },
        0.70
      );

      scrollTl.fromTo(
        subheadline,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.72
      );

      scrollTl.fromTo(
        cta,
        { y: 0, scale: 1, opacity: 1 },
        { y: '22vh', scale: 0.85, opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(
        bg,
        { scale: 1.02, opacity: 1 },
        { scale: 1.08, opacity: 0.85, ease: 'power2.in' },
        0.70
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned z-10"
    >
      {/* Background Image */}
      <div ref={bgRef} className="absolute inset-0">
        <img
          src="/hero_living_room.jpg"
          alt="Luxury Interior"
          className="bg-image"
        />
        <div className="bg-overlay" />
      </div>

      {/* Content */}
      <div className="relative z-10 h-full flex flex-col justify-center px-[7vw]">
        {/* Headline */}
        <div ref={headlineRef} className="max-w-[62vw] mt-[-8vh]">
          <h1 className="headline-xl text-[#F5F2EC]">
            <span className="word inline-block">Elevate</span>
            <br />
            <span className="word inline-block">Your</span>
            <br />
            <span className="word inline-block">Lifestyle</span>
          </h1>
        </div>

        {/* Subheadline */}
        <p
          ref={subheadlineRef}
          className="body-text text-[#B8B2AA] max-w-[34vw] mt-8"
        >
          Residential, retail & commercial interiors—designed with restraint, built with care.
        </p>
      </div>

      {/* CTA Circle */}
      <button
        ref={ctaRef}
        onClick={onEnterClick}
        className="cta-circle absolute left-1/2 bottom-[7vh] -translate-x-1/2 z-20"
      >
        <span>Enter here</span>
      </button>

      {/* Scroll hint */}
      <p className="absolute left-1/2 bottom-[4vh] -translate-x-1/2 label-small text-[#F5F2EC] opacity-50 z-10">
        Scroll to explore
      </p>
    </section>
  );
}
