import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function DiningSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const indexRef = useRef<HTMLSpanElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // Phase 1: ENTRANCE (0%-30%) - with x translation from left for variation
      scrollTl.fromTo(
        bgRef.current,
        { x: '-8vw', scale: 1.08, opacity: 0.7 },
        { x: 0, scale: 1.00, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        headlineRef.current?.querySelectorAll('.word') || [],
        { x: '-50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'power2.out', stagger: 0.04 },
        0
      );

      scrollTl.fromTo(
        bodyRef.current,
        { x: '-18vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'power2.out' },
        0.10
      );

      scrollTl.fromTo(
        ctaRef.current,
        { y: '22vh', scale: 0.8, opacity: 0 },
        { y: 0, scale: 1, opacity: 1, ease: 'back.out(1.5)' },
        0.14
      );

      scrollTl.fromTo(
        indexRef.current,
        { opacity: 0 },
        { opacity: 1, ease: 'none' },
        0.15
      );

      // Phase 3: EXIT (70%-100%)
      scrollTl.fromTo(
        headlineRef.current?.querySelectorAll('.word') || [],
        { x: 0, opacity: 1 },
        { x: '-45vw', opacity: 0, ease: 'power2.in', stagger: 0.02 },
        0.70
      );

      scrollTl.fromTo(
        bodyRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.72
      );

      scrollTl.fromTo(
        ctaRef.current,
        { y: 0, opacity: 1 },
        { y: '22vh', opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(
        indexRef.current,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.75
      );

      scrollTl.fromTo(
        bgRef.current,
        { scale: 1.00, opacity: 1 },
        { scale: 1.07, opacity: 0.85, ease: 'power2.in' },
        0.70
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned z-[60]"
    >
      {/* Background Image */}
      <div ref={bgRef} className="absolute inset-0">
        <img
          src="/dining_feature.jpg"
          alt="Elegant Dining"
          className="bg-image"
        />
        <div className="bg-overlay" style={{ background: 'rgba(11, 11, 13, 0.48)' }} />
      </div>

      {/* Index Number */}
      <span 
        ref={indexRef}
        className="index-number absolute right-[7vw] top-[10vh] z-10"
      >
        04
      </span>

      {/* Content */}
      <div className="relative z-10 h-full flex flex-col justify-center px-[7vw]">
        {/* Headline */}
        <div ref={headlineRef} className="max-w-[55vw]">
          <h2 className="headline-xl text-[#F5F2EC]">
            <span className="word inline-block">Elegant</span>
            <br />
            <span className="word inline-block">Dining</span>
          </h2>
        </div>

        {/* Body */}
        <p
          ref={bodyRef}
          className="body-text text-[#B8B2AA] max-w-[34vw] mt-12"
        >
          A table that anchors the room, lighting that sets the mood, and details that feel considered.
        </p>
      </div>

      {/* CTA Circle */}
      <button
        ref={ctaRef}
        className="cta-circle absolute left-1/2 bottom-[7vh] -translate-x-1/2 z-20"
      >
        <span>View project</span>
      </button>
    </section>
  );
}
